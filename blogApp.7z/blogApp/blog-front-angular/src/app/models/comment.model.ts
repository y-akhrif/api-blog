
export class Comment {

  id?: number;
  email: string;
  message: string;
  website: string;
}
