import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {HttpClientModule} from "@angular/common/http";


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { BlogComponent } from './blog/blog.component';
import { BlogService} from './blog/blog.service';
import { AddBlogComponent} from './blog/add-blog.component';
import { EditBlogComponent} from './blog/edit-blog.component';
import { DetailBlogComponent} from './blog/detail-blog.component';
import { EditCommentComponent} from './blog/edit-comment.component';


@NgModule({
  declarations: [
    AppComponent,
    BlogComponent,
    AddBlogComponent,
    EditBlogComponent,
    DetailBlogComponent,
    EditCommentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
  ],
  providers: [BlogService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
