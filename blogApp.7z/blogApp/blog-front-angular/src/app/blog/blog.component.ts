import { Component, PipeTransform  , OnInit, Directive, EventEmitter, Input, Output, QueryList, ViewChildren} from '@angular/core';
import {DecimalPipe} from '@angular/common';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';

import {Observable} from 'rxjs';

import { BlogService } from './blog.service';
import { Blog } from '../models/blog.model';



@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css'],
  providers: [ DecimalPipe]

})


export class BlogComponent implements OnInit {

  listBlogs: Blog[];

  page = 1;
  pageSize = 5;
  collectionSize = 0;


  constructor(private router: Router, private blogService: BlogService) {

  }

  ngOnInit() {
     this.blogService.getBlogs()
      .subscribe( data => {
         this.listBlogs = data;
         this.collectionSize = this.listBlogs.length;
     });
  }


  get blogs(): Blog[]   {
     if (this.listBlogs != null) {
            return  this.listBlogs.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);

     } else {
        return  this.listBlogs; 
     }

  }

  deleteBlog(blog: Blog): void {
  
	   if (confirm('Are you sure you want to remove the blog ' + blog.id + '#' + blog.title)) {
	   
		   this.blogService.deleteBlog(blog)
		      .subscribe( data => {
		        this.listBlogs = this.listBlogs.filter(u => u !== blog);
		         this.collectionSize =  this.collectionSize -1;
		    })
	   }
  }


}


