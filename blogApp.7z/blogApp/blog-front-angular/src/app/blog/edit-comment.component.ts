import { Component,OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';


import { Comment } from '../models/comment.model';
import { BlogService } from './blog.service';

@Component({
  selector: 'edit-comment',
  templateUrl: './edit-comment.component.html'
})
export class EditCommentComponent  implements OnInit{
  
  comment: Comment = new Comment();
  blogId:Number;

  constructor(private appComponent: AppComponent,private route: ActivatedRoute, private blogService: BlogService, private location: Location) {

  }
  
  
  ngOnInit() {
  
 
    const id = +this.route.snapshot.paramMap.get('commentId');
    this.blogId = +this.route.snapshot.paramMap.get('blogId');
    if (id !== 0) {
        this.blogService.getComment(id)
             .subscribe(data => {this.comment = data;
             });
    }
   
  }


  editComment(): void {
  
    this.blogService.editComment(this.comment)
        .subscribe( data => {
           this.appComponent.alsertClosed = false;
           this.appComponent.alsertMessage = 'The comment with id "'+ this.comment.id+'" has been update successfully.';
           this.goBack();
        });
  }
  
  

  goBack(): void {
     this.location.back();
  }
  
  onSubmit() {
    this.editComment();
  }
}
